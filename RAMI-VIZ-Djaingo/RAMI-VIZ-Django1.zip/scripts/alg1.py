"""
Algorithm 1: Input Specification and Preprocessing
"""
REQUIRED_KEYS = [
    "microsystem.id", "microsystem.name", "microsystem.description",
    "microsystem.type", "microsystem.role", "microsystem.asset",
    "microsystem.shell", "microsystem.provides", "microsystem.consumes",
    "microsystem_stakeholder.id", "microsystem_stakeholder.description"
]

def validate_microsystem(micro):
    for key in REQUIRED_KEYS:
        keys = key.split('.')
        val = micro
        for k in keys:
            if k in val:
                val = val[k]
            else:
                return False, f"Missing required field: {key}"
    return True, ""

def run(input_json):
    microsystems = input_json.get("microsystems", [])
    validated, errors = [], []
    for idx, micro in enumerate(microsystems):
        is_valid, err = validate_microsystem(micro)
        if is_valid: validated.append(micro)
        else: errors.append({"index": idx, "error": err})
    return validated, errors
