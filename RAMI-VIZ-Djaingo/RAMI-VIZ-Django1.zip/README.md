# RAMI-VIZ: Django-based Runtime Visualization of RAMI 4.0 Systems

**RAMI-VIZ** is a web application to visualize microsystem interactions and value flows in cyber-physical systems using the RAMI 4.0 reference model.

## Features
- Upload JSON DSL system models
- Run full pipeline of 7 analysis algorithms
- View 3D RAMI cube with Plotly.js
- See 2D value projection heatmap
- Lightweight, modular, and dockerized

## How to Run

### With Docker
```bash
docker-compose up --build
```

### Access the tool:
Go to `http://localhost:8000` and upload `sample_shp_input.json`.

## Structure
- `scripts/` – all core algorithms (1–7)
- `ramiviz/` – Django app views and routes
- `templates/` – HTML + Plotly frontend
- `demo_files/` – sample SHP use case
- `media/` – uploaded input models

## Author
Salman Javed – PhD, Cyber-Physical Systems  
[Dissertation & Demo](https://staff.www.ltu.se/~javsal/RAMIX/ramix-toolchain.mp4)  
[GitHub](https://github.com/javedsalman)
