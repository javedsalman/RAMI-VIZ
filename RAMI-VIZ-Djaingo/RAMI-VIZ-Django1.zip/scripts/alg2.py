"""
Algorithm 2: RAMI 4.0 Axis Mapping
"""
X_RULES = {
    ("Field Device", "sensor"): 1.0, ("Control Device", "controller"): 2.0,
    ("Station", "assembly"): 3.0, ("Work Center", "workflow"): 4.0,
    ("Enterprise", "analytics"): 5.0, ("Connected World", "cloud"): 6.0
}
Y_RULES = {"provides": {"design_docs": 0.0, "support_data": 1.0,
                        "machine_data": 2.0, "maintenance_logs": 3.0}}
Z_RULES = {"shell": {"physical": 0, "integration": 1, "communication": 2,
                     "information": 3, "function": 4, "business": 5}}

def map_x_axis(micro):
    return X_RULES.get((micro["microsystem"]["type"], micro["microsystem"]["role"]), -1.0)

def map_y_axis(micro):
    for item in micro["microsystem"].get("provides", []):
        for ref, y in Y_RULES["provides"].items():
            if ref in item: return y
    return -1.0

def map_z_axis(micro):
    zvals = []
    for item in micro["microsystem"].get("shell", []):
        for key, z in Z_RULES["shell"].items():
            if key in item.lower(): zvals.append(z)
    return list(set(zvals))

def run(validated_microsystems):
    result = []
    for m in validated_microsystems:
        m["coordinates"] = {
            "x": map_x_axis(m), "y": map_y_axis(m), "z": map_z_axis(m)
        }
        result.append(m)
    return result
