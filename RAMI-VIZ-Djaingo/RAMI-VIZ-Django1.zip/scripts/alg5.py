"""
Algorithm 5: 3D Point Mapping
"""
import random

def generate_3d_points(microsystems, clusters):
    result = []
    for i, m in enumerate(microsystems):
        coords = m.get("coordinates", {})
        zlist = coords.get("z", [])
        for z in zlist:
            result.append({
                "id": m["microsystem"]["id"], "name": m["microsystem"]["name"],
                "x": coords.get("x", -1) + random.uniform(-0.1, 0.1),
                "y": coords.get("y", -1) + random.uniform(-0.1, 0.1),
                "z": z + random.uniform(-0.1, 0.1),
                "cluster": clusters.get(i, -1),
                "stakeholder": m["microsystem_stakeholder"]["description"],
                "type": m["microsystem"]["type"]
            })
    return result
