from django.apps import AppConfig

class RamivizConfig(AppConfig):
    name = 'ramiviz'
