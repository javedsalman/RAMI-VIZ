"""
Algorithm 7: Lifecycle and Phase Mapping
"""
def run(microsystems):
    timeline, phases = [], set()
    for m in microsystems:
        phase = m.get("microsystem", {}).get("phase", "unspecified")
        x = m["coordinates"].get("x", -1)
        y = m["coordinates"].get("y", -1)
        phases.add(phase)
        timeline.append({
            "id": m["microsystem"]["id"],
            "phase": phase, "x": x, "y": y,
            "description": m["microsystem"].get("name", "")
        })
    return {"phases": list(phases), "timeline": timeline}
