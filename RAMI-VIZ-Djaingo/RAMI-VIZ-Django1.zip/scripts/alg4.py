"""
Algorithm 4: Interaction Matrix & Clustering
"""
import numpy as np

def build_interaction_matrix(microsystems):
    ids = [m["microsystem"]["id"] for m in microsystems]
    idx_map = {id_: i for i, id_ in enumerate(ids)}
    matrix = np.zeros((len(ids), len(ids)))
    for s in microsystems:
        i = idx_map[s["microsystem"]["id"]]
        for t in s["microsystem"].get("interactions", []):
            if t in idx_map: matrix[i][idx_map[t]] += 1
    return matrix, idx_map, ids

def cluster_microsystems(matrix, threshold=1):
    return {i: (i if np.sum(matrix[i]) >= threshold else -1)
            for i in range(matrix.shape[0])}

def run(microsystems, threshold=1):
    mtx, idx_map, ids = build_interaction_matrix(microsystems)
    clusters = cluster_microsystems(mtx, threshold)
    return {
        "matrix": mtx.tolist(),
        "index_map": idx_map,
        "reverse_map": ids,
        "clusters": clusters
    }
