"""
Algorithm 3: Workflow Filtering
"""
def run(mapped, workflow_services):
    relevant = []
    for m in mapped:
        provides = m["microsystem"].get("provides", [])
        consumes = m["microsystem"].get("consumes", [])
        if any(s in provides for s in workflow_services) or any(s in consumes for s in workflow_services):
            relevant.append(m)
    return relevant
