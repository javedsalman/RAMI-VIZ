"""
Algorithm 6: Value Projection on RAMI Cube
"""
def run(microsystems):
    return [{
        "id": m["microsystem"]["id"],
        "x": m["coordinates"].get("x", -1),
        "y": m["coordinates"].get("y", -1),
        "cost": m.get("metrics", {}).get("cost", 0),
        "value": m.get("metrics", {}).get("value", 0)
    } for m in microsystems]
